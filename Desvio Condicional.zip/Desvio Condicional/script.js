let Nota1 = document.querySelector("#Nota1");
let Nota2 = document.querySelector("#Nota2");
let btCalcularNotas = document.querySelector("#btCalcularNotas");
let Resultado = document.querySelector("#Resultado");

function verificarAprovacao() {
  let num1 = Number(Nota1.value);
  let num2 = Number(Nota2.value);
  let media = num1 + num2 / 2;

  //APROVADO: média 6.0 ou maior
  //REPROVADO: média menor que 6.0
  if(media >= 6.0){
    Resultado.textContent = "Parabéns você esta aprovado!!!"
  }else{
    Resultado.textContent = "Não desista, tente novamente!"
  }
}

btCalcularNotas.onclick = function() {
    verificarAprovacao();
}